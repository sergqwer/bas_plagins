var bnggsfit = GetInputConstructorValue("bnggsfit", loader);
                 if(bnggsfit["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var ampupdfq = GetInputConstructorValue("ampupdfq", loader);
                 if(ampupdfq["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var pxvhlded = GetInputConstructorValue("pxvhlded", loader);
                 if(pxvhlded["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var dslwfpak = GetInputConstructorValue("dslwfpak", loader);
                 if(dslwfpak["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var dzqnjgip = GetInputConstructorValue("dzqnjgip", loader);
                 if(dzqnjgip["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GeeTest_icon_SolverGeetestIcon_code").html())({"bnggsfit": bnggsfit["updated"],"ampupdfq": ampupdfq["updated"],"pxvhlded": pxvhlded["updated"],"dslwfpak": dslwfpak["updated"],"dzqnjgip": dzqnjgip["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
