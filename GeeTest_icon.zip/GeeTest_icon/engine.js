function GeeTest_icon_AllowCacheForGeetestIcon()
   {
   
      
      
      /*Browser*/
      cache_allow("https://static.geetest.com/captcha_v4/policy/*")!
      

      
      
      /*Browser*/
      cache_allow("https://static.geetest.com/nerualpic/original_icon_pic/*")!
      

   }
   

function GeeTest_icon_SolverGeetestIcon()
   {
   
      
      
      VAR_BUTTON_CAPTHCA = _function_argument("button_capthca")
      

      
      
      VAR_FOTO_CAPTCHA = _function_argument("foto_captcha")
      

      
      
      VAR_RELOAD_CAPTCHA = _function_argument("reload_captcha")
      

      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      VAR_CAPTCHA_SUBMIT = _function_argument("captcha_submit")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:"([A-Za-z0-9]+)"}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      

      
      
      _set_if_expression("W1tBUElLRVldXSA9PSAiIg==");
      _if(VAR_APIKEY == "",function(){
      
         
         
         fail_user("Bad API key",false)
         

      })!
      

      
      
      VAR_URL_ADRESS_SOLVER = "http://127.0.0.1:10000"
      

      
      
      VAR_URL_ADRESS_SOLVER = "http://goodxevilpay.shop"
      

      
      
      VAR_TRY_SOLVE = 0
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = true;
      if(!BREAK_CONDITION)_break();
      
         
         
         _set_if_expression("W1tUUllfU09MVkVdXSA+PSAxMA==");
         _if(VAR_TRY_SOLVE >= 10,function(){
         
            
            
            fail_user("Fail solve captcha try: " + VAR_TRY_SOLVE,false)
            

         })!
         

         
         
         VAR_FIND_FOTO = 0
         

         
         
         _do(function(){
         _set_action_info({ name: "While" });
         VAR_CYCLE_INDEX = _iterator() - 1
         BREAK_CONDITION = true;
         if(!BREAK_CONDITION)_break();
         
            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMTA=");
            _if(VAR_CYCLE_INDEX > 10,function(){
            
               
               
               VAR_FIND_FOTO = 0
               

               
               
               _break("function")
               

            })!
            

            
            
            _set_if_expression("W1tUUllfU09MVkVdXSAhPSAw");
            _if(VAR_TRY_SOLVE != 0,function(){
            
               
               
               _do(function(){
               _set_action_info({ name: "While" });
               VAR_CYCLE_INDEX = _iterator() - 1
               BREAK_CONDITION = true;
               if(!BREAK_CONDITION)_break();
               
                  
                  
                  _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNQ==");
                  _if(VAR_CYCLE_INDEX > 5,function(){
                  
                     
                     
                     _function_return("GoodSolver")
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR=VAR_BUTTON_CAPTHCA;
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     _break("function")
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR=VAR_RELOAD_CAPTCHA;
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     _break("function")
                     

                  })!
                  

               })!
               

            })!
            

            
            
            /*Browser*/
            IDDLE_EMULATION_END = Date.now() + 1000 * (1)
            IDDLE_EMULATION_DISTRIBUTION = [2,3,3,3,4,4]
            _get_browser_screen_settings()!
            IDDLE_EMULATION_RESULT = JSON.parse(_result())
            IDDLE_CURSOR_POSITION_X = IDDLE_EMULATION_RESULT["CursorX"]
            IDDLE_CURSOR_POSITION_Y = IDDLE_EMULATION_RESULT["CursorY"]
            IDDLE_CURSOR_POSITION_WIDTH = IDDLE_EMULATION_RESULT["Width"]
            IDDLE_CURSOR_POSITION_HEIGHT = IDDLE_EMULATION_RESULT["Height"]
            IDDLE_CURSOR_POSITION_WAS_SCROLL = false
            _do(function(){
            if(Date.now() >= IDDLE_EMULATION_END)
            _break()
            IDDLE_EMULATION_CURRENT_ITEM = IDDLE_EMULATION_DISTRIBUTION[Math.floor(Math.random()*IDDLE_EMULATION_DISTRIBUTION.length)]
            if(_iterator() == 1 && IDDLE_EMULATION_DISTRIBUTION.indexOf(2)>=0)
            IDDLE_EMULATION_CURRENT_ITEM = 2
            _if(IDDLE_EMULATION_CURRENT_ITEM == 1, function(){
            //scroll
            IDDLE_EMULATION_CURRENT_DIRECTION = (rand(1,2) == 2) ? "<MOUSESCROLLUP>" : "<MOUSESCROLLDOWN>"
            if(!IDDLE_CURSOR_POSITION_WAS_SCROLL)
            IDDLE_EMULATION_CURRENT_DIRECTION = "<MOUSESCROLLDOWN>"
            IDDLE_CURSOR_POSITION_WAS_SCROLL = true
            IDDLE_EMULATION_CURRENT_NUMBER = rand(1,5)
            _do(function(){
            if(_iterator() >= IDDLE_EMULATION_CURRENT_NUMBER)
            _break()
            _type(IDDLE_EMULATION_CURRENT_DIRECTION,1000)!
            sleep(rand(300,1000))!
            })!
            })!
            _if(IDDLE_EMULATION_CURRENT_ITEM == 2, function(){
            //long move
            page().script("document.documentElement.scrollLeft")!
            IDDLE_CURSOR_POSITION_SCROLL_X = parseInt(_result())
            page().script("document.documentElement.scrollTop")!
            IDDLE_CURSOR_POSITION_SCROLL_Y = parseInt(_result())
            IDDLE_CURSOR_POSITION_X = rand(1,IDDLE_CURSOR_POSITION_WIDTH)
            IDDLE_CURSOR_POSITION_Y = rand(1,IDDLE_CURSOR_POSITION_HEIGHT)
            move(IDDLE_CURSOR_POSITION_SCROLL_X + IDDLE_CURSOR_POSITION_X,IDDLE_CURSOR_POSITION_SCROLL_Y + IDDLE_CURSOR_POSITION_Y)!
            })!
            _if(IDDLE_EMULATION_CURRENT_ITEM == 3, function(){
            //short move
            if(IDDLE_CURSOR_POSITION_X < 0 || IDDLE_CURSOR_POSITION_Y < 0)
            _break()
            page().script("document.documentElement.scrollLeft")!
            IDDLE_CURSOR_POSITION_SCROLL_X = parseInt(_result())
            page().script("document.documentElement.scrollTop")!
            IDDLE_CURSOR_POSITION_SCROLL_Y = parseInt(_result())
            IDDLE_EMULATION_CURRENT_NUMBER = rand(1,4)
            _do(function(){
            if(_iterator() >= IDDLE_EMULATION_CURRENT_NUMBER)
            _break()
            IDDLE_CURSOR_POSITION_X += rand(-50,50)
            IDDLE_CURSOR_POSITION_Y += rand(-50,50)
            if(IDDLE_CURSOR_POSITION_X > IDDLE_CURSOR_POSITION_WIDTH)
            IDDLE_CURSOR_POSITION_X = IDDLE_CURSOR_POSITION_WIDTH
            if(IDDLE_CURSOR_POSITION_Y > IDDLE_CURSOR_POSITION_HEIGHT)
            IDDLE_CURSOR_POSITION_Y = IDDLE_CURSOR_POSITION_HEIGHT
            if(IDDLE_CURSOR_POSITION_X < 0)
            IDDLE_CURSOR_POSITION_X = 0
            if(IDDLE_CURSOR_POSITION_Y < 0)
            IDDLE_CURSOR_POSITION_Y = 0
            move(IDDLE_CURSOR_POSITION_SCROLL_X + IDDLE_CURSOR_POSITION_X,IDDLE_CURSOR_POSITION_SCROLL_Y + IDDLE_CURSOR_POSITION_Y)!
            _if(rand(1,10) > 3,function(){
            sleep(rand(10,300))!
            })!
            })!
            })!
            _if(IDDLE_EMULATION_CURRENT_ITEM == 4, function(){
            //sleep
            sleep(rand(500,5000))!
            })!
            })!
            

            
            
            /*Browser*/
            _cache_get_all("https://static.geetest.com/captcha_v4/policy/*")!
            VAR_CACHE_LIST = JSON.parse(_result())
            

            
            
            VAR_LIST_LENGTH = (VAR_CACHE_LIST).length
            

            
            
            _set_if_expression("W1tMSVNUX0xFTkdUSF1dID09IDA=");
            _if(VAR_LIST_LENGTH == 0,function(){
            
               
               
               _next("function")
               

            })!
            

            
            
            VAR_MAIN_FOTO = VAR_CACHE_LIST[0]["body"]
            

            
            
            _set_if_expression("W1tNQUlOX0ZPVE9dXSA9PSAiIg==");
            _if(VAR_MAIN_FOTO == "",function(){
            
               
               
               _next("function")
               

            })!
            

            
            
            /*Browser*/
            IDDLE_EMULATION_END = Date.now() + 1000 * (1)
            IDDLE_EMULATION_DISTRIBUTION = [2,3,3,3,4,4]
            _get_browser_screen_settings()!
            IDDLE_EMULATION_RESULT = JSON.parse(_result())
            IDDLE_CURSOR_POSITION_X = IDDLE_EMULATION_RESULT["CursorX"]
            IDDLE_CURSOR_POSITION_Y = IDDLE_EMULATION_RESULT["CursorY"]
            IDDLE_CURSOR_POSITION_WIDTH = IDDLE_EMULATION_RESULT["Width"]
            IDDLE_CURSOR_POSITION_HEIGHT = IDDLE_EMULATION_RESULT["Height"]
            IDDLE_CURSOR_POSITION_WAS_SCROLL = false
            _do(function(){
            if(Date.now() >= IDDLE_EMULATION_END)
            _break()
            IDDLE_EMULATION_CURRENT_ITEM = IDDLE_EMULATION_DISTRIBUTION[Math.floor(Math.random()*IDDLE_EMULATION_DISTRIBUTION.length)]
            if(_iterator() == 1 && IDDLE_EMULATION_DISTRIBUTION.indexOf(2)>=0)
            IDDLE_EMULATION_CURRENT_ITEM = 2
            _if(IDDLE_EMULATION_CURRENT_ITEM == 1, function(){
            //scroll
            IDDLE_EMULATION_CURRENT_DIRECTION = (rand(1,2) == 2) ? "<MOUSESCROLLUP>" : "<MOUSESCROLLDOWN>"
            if(!IDDLE_CURSOR_POSITION_WAS_SCROLL)
            IDDLE_EMULATION_CURRENT_DIRECTION = "<MOUSESCROLLDOWN>"
            IDDLE_CURSOR_POSITION_WAS_SCROLL = true
            IDDLE_EMULATION_CURRENT_NUMBER = rand(1,5)
            _do(function(){
            if(_iterator() >= IDDLE_EMULATION_CURRENT_NUMBER)
            _break()
            _type(IDDLE_EMULATION_CURRENT_DIRECTION,1000)!
            sleep(rand(300,1000))!
            })!
            })!
            _if(IDDLE_EMULATION_CURRENT_ITEM == 2, function(){
            //long move
            page().script("document.documentElement.scrollLeft")!
            IDDLE_CURSOR_POSITION_SCROLL_X = parseInt(_result())
            page().script("document.documentElement.scrollTop")!
            IDDLE_CURSOR_POSITION_SCROLL_Y = parseInt(_result())
            IDDLE_CURSOR_POSITION_X = rand(1,IDDLE_CURSOR_POSITION_WIDTH)
            IDDLE_CURSOR_POSITION_Y = rand(1,IDDLE_CURSOR_POSITION_HEIGHT)
            move(IDDLE_CURSOR_POSITION_SCROLL_X + IDDLE_CURSOR_POSITION_X,IDDLE_CURSOR_POSITION_SCROLL_Y + IDDLE_CURSOR_POSITION_Y)!
            })!
            _if(IDDLE_EMULATION_CURRENT_ITEM == 3, function(){
            //short move
            if(IDDLE_CURSOR_POSITION_X < 0 || IDDLE_CURSOR_POSITION_Y < 0)
            _break()
            page().script("document.documentElement.scrollLeft")!
            IDDLE_CURSOR_POSITION_SCROLL_X = parseInt(_result())
            page().script("document.documentElement.scrollTop")!
            IDDLE_CURSOR_POSITION_SCROLL_Y = parseInt(_result())
            IDDLE_EMULATION_CURRENT_NUMBER = rand(1,4)
            _do(function(){
            if(_iterator() >= IDDLE_EMULATION_CURRENT_NUMBER)
            _break()
            IDDLE_CURSOR_POSITION_X += rand(-50,50)
            IDDLE_CURSOR_POSITION_Y += rand(-50,50)
            if(IDDLE_CURSOR_POSITION_X > IDDLE_CURSOR_POSITION_WIDTH)
            IDDLE_CURSOR_POSITION_X = IDDLE_CURSOR_POSITION_WIDTH
            if(IDDLE_CURSOR_POSITION_Y > IDDLE_CURSOR_POSITION_HEIGHT)
            IDDLE_CURSOR_POSITION_Y = IDDLE_CURSOR_POSITION_HEIGHT
            if(IDDLE_CURSOR_POSITION_X < 0)
            IDDLE_CURSOR_POSITION_X = 0
            if(IDDLE_CURSOR_POSITION_Y < 0)
            IDDLE_CURSOR_POSITION_Y = 0
            move(IDDLE_CURSOR_POSITION_SCROLL_X + IDDLE_CURSOR_POSITION_X,IDDLE_CURSOR_POSITION_SCROLL_Y + IDDLE_CURSOR_POSITION_Y)!
            _if(rand(1,10) > 3,function(){
            sleep(rand(10,300))!
            })!
            })!
            })!
            _if(IDDLE_EMULATION_CURRENT_ITEM == 4, function(){
            //sleep
            sleep(rand(500,5000))!
            })!
            })!
            

            
            
            /*Browser*/
            _cache_get_all("https://static.geetest.com/nerualpic/original_icon_pic/*")!
            VAR_CACHE_LIST = JSON.parse(_result())
            

            
            
            VAR_LIST_LENGTH = (VAR_CACHE_LIST).length
            

            
            
            _set_if_expression("W1tMSVNUX0xFTkdUSF1dICE9IDM=");
            _if(VAR_LIST_LENGTH != 3,function(){
            
               
               
               VAR_FIND_FOTO = 0
               

               
               
               _break("function")
               

            })!
            

            
            
            VAR_MAIN_FOTO = VAR_CACHE_LIST[0]["body"]
            

            
            
            VAR_FIND_FOTO = 1
            

            
            
            _break("function")
            

         })!
         

         
         
         _cycle_params().if_else = VAR_FIND_FOTO == 0;
         _set_if_expression("W1tGSU5EX0ZPVE9dXSA9PSAw");
         _if(_cycle_params().if_else,function(){
         
            
            
            _do(function(){
            _set_action_info({ name: "While" });
            VAR_CYCLE_INDEX = _iterator() - 1
            BREAK_CONDITION = true;
            if(!BREAK_CONDITION)_break();
            
               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNSAmJiBbW1RSWV9TT0xWRV1dID4gMA==");
               _if(VAR_CYCLE_INDEX > 5 && VAR_TRY_SOLVE > 0,function(){
               
                  
                  
                  _function_return("GoodSolver")
                  

               })!
               

               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMTU=");
               _if(VAR_CYCLE_INDEX > 15,function(){
               
                  
                  
                  fail_user("Не дождался кнопку с капчей",false)
                  

               })!
               

               
               
               /*Browser*/
               ;_SELECTOR=VAR_BUTTON_CAPTHCA;
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR=VAR_RELOAD_CAPTCHA;
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     /*Browser*/
                     _SELECTOR = VAR_RELOAD_CAPTCHA;
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {} )!
                     mouse(X,Y)!
                     })!
                     

                     
                     
                     _break("function")
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  _SELECTOR = VAR_BUTTON_CAPTHCA;
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {} )!
                  mouse(X,Y)!
                  })!
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               /*Browser*/
               ;_SELECTOR=VAR_RELOAD_CAPTCHA;
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  /*Browser*/
                  _SELECTOR = VAR_RELOAD_CAPTCHA;
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {} )!
                  mouse(X,Y)!
                  })!
                  

                  
                  
                  _break("function")
                  

               })!
               

            })!
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            _do(function(){
            _set_action_info({ name: "While" });
            VAR_CYCLE_INDEX = _iterator() - 1
            BREAK_CONDITION = true;
            if(!BREAK_CONDITION)_break();
            
               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNSAmJiBbW1RSWV9TT0xWRV1dID4gMA==");
               _if(VAR_CYCLE_INDEX > 5 && VAR_TRY_SOLVE > 0,function(){
               
                  
                  
                  _function_return("GoodSolver")
                  

               })!
               

               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMzA=");
               _if(VAR_CYCLE_INDEX > 30,function(){
               
                  
                  
                  fail_user("Не дождался кнопку с капчей",false)
                  

               })!
               

               
               
               /*Browser*/
               ;_SELECTOR=VAR_BUTTON_CAPTHCA;
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR=VAR_RELOAD_CAPTCHA;
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     _break("function")
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  _SELECTOR = VAR_BUTTON_CAPTHCA;
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {} )!
                  mouse(X,Y)!
                  })!
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               /*Browser*/
               ;_SELECTOR=VAR_RELOAD_CAPTCHA;
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  _break("function")
                  

               })!
               

            })!
            

         })!
         delete _cycle_params().if_else;
         

         
         
         VAR_ERROR_FIND_TASK_IMAGES = 0
         

         
         
         _do(function(){
         _set_action_info({ name: "While" });
         VAR_CYCLE_INDEX = _iterator() - 1
         BREAK_CONDITION = true;
         if(!BREAK_CONDITION)_break();
         
            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMTA=");
            _if(VAR_CYCLE_INDEX > 10,function(){
            
               
               
               fail_user("Не дождался фото",false)
               

            })!
            

            
            
            /*Browser*/
            IDDLE_EMULATION_END = Date.now() + 1000 * (1)
            IDDLE_EMULATION_DISTRIBUTION = [2,3,3,3,4,4]
            _get_browser_screen_settings()!
            IDDLE_EMULATION_RESULT = JSON.parse(_result())
            IDDLE_CURSOR_POSITION_X = IDDLE_EMULATION_RESULT["CursorX"]
            IDDLE_CURSOR_POSITION_Y = IDDLE_EMULATION_RESULT["CursorY"]
            IDDLE_CURSOR_POSITION_WIDTH = IDDLE_EMULATION_RESULT["Width"]
            IDDLE_CURSOR_POSITION_HEIGHT = IDDLE_EMULATION_RESULT["Height"]
            IDDLE_CURSOR_POSITION_WAS_SCROLL = false
            _do(function(){
            if(Date.now() >= IDDLE_EMULATION_END)
            _break()
            IDDLE_EMULATION_CURRENT_ITEM = IDDLE_EMULATION_DISTRIBUTION[Math.floor(Math.random()*IDDLE_EMULATION_DISTRIBUTION.length)]
            if(_iterator() == 1 && IDDLE_EMULATION_DISTRIBUTION.indexOf(2)>=0)
            IDDLE_EMULATION_CURRENT_ITEM = 2
            _if(IDDLE_EMULATION_CURRENT_ITEM == 1, function(){
            //scroll
            IDDLE_EMULATION_CURRENT_DIRECTION = (rand(1,2) == 2) ? "<MOUSESCROLLUP>" : "<MOUSESCROLLDOWN>"
            if(!IDDLE_CURSOR_POSITION_WAS_SCROLL)
            IDDLE_EMULATION_CURRENT_DIRECTION = "<MOUSESCROLLDOWN>"
            IDDLE_CURSOR_POSITION_WAS_SCROLL = true
            IDDLE_EMULATION_CURRENT_NUMBER = rand(1,5)
            _do(function(){
            if(_iterator() >= IDDLE_EMULATION_CURRENT_NUMBER)
            _break()
            _type(IDDLE_EMULATION_CURRENT_DIRECTION,1000)!
            sleep(rand(300,1000))!
            })!
            })!
            _if(IDDLE_EMULATION_CURRENT_ITEM == 2, function(){
            //long move
            page().script("document.documentElement.scrollLeft")!
            IDDLE_CURSOR_POSITION_SCROLL_X = parseInt(_result())
            page().script("document.documentElement.scrollTop")!
            IDDLE_CURSOR_POSITION_SCROLL_Y = parseInt(_result())
            IDDLE_CURSOR_POSITION_X = rand(1,IDDLE_CURSOR_POSITION_WIDTH)
            IDDLE_CURSOR_POSITION_Y = rand(1,IDDLE_CURSOR_POSITION_HEIGHT)
            move(IDDLE_CURSOR_POSITION_SCROLL_X + IDDLE_CURSOR_POSITION_X,IDDLE_CURSOR_POSITION_SCROLL_Y + IDDLE_CURSOR_POSITION_Y)!
            })!
            _if(IDDLE_EMULATION_CURRENT_ITEM == 3, function(){
            //short move
            if(IDDLE_CURSOR_POSITION_X < 0 || IDDLE_CURSOR_POSITION_Y < 0)
            _break()
            page().script("document.documentElement.scrollLeft")!
            IDDLE_CURSOR_POSITION_SCROLL_X = parseInt(_result())
            page().script("document.documentElement.scrollTop")!
            IDDLE_CURSOR_POSITION_SCROLL_Y = parseInt(_result())
            IDDLE_EMULATION_CURRENT_NUMBER = rand(1,4)
            _do(function(){
            if(_iterator() >= IDDLE_EMULATION_CURRENT_NUMBER)
            _break()
            IDDLE_CURSOR_POSITION_X += rand(-50,50)
            IDDLE_CURSOR_POSITION_Y += rand(-50,50)
            if(IDDLE_CURSOR_POSITION_X > IDDLE_CURSOR_POSITION_WIDTH)
            IDDLE_CURSOR_POSITION_X = IDDLE_CURSOR_POSITION_WIDTH
            if(IDDLE_CURSOR_POSITION_Y > IDDLE_CURSOR_POSITION_HEIGHT)
            IDDLE_CURSOR_POSITION_Y = IDDLE_CURSOR_POSITION_HEIGHT
            if(IDDLE_CURSOR_POSITION_X < 0)
            IDDLE_CURSOR_POSITION_X = 0
            if(IDDLE_CURSOR_POSITION_Y < 0)
            IDDLE_CURSOR_POSITION_Y = 0
            move(IDDLE_CURSOR_POSITION_SCROLL_X + IDDLE_CURSOR_POSITION_X,IDDLE_CURSOR_POSITION_SCROLL_Y + IDDLE_CURSOR_POSITION_Y)!
            _if(rand(1,10) > 3,function(){
            sleep(rand(10,300))!
            })!
            })!
            })!
            _if(IDDLE_EMULATION_CURRENT_ITEM == 4, function(){
            //sleep
            sleep(rand(500,5000))!
            })!
            })!
            

            
            
            /*Browser*/
            _cache_get_all("https://static.geetest.com/captcha_v4/policy/*")!
            VAR_CACHE_LIST = JSON.parse(_result())
            

            
            
            VAR_LIST_LENGTH = (VAR_CACHE_LIST).length
            

            
            
            _set_if_expression("W1tMSVNUX0xFTkdUSF1dID09IDA=");
            _if(VAR_LIST_LENGTH == 0,function(){
            
               
               
               _next("function")
               

            })!
            

            
            
            VAR_MAIN_FOTO = VAR_CACHE_LIST[0]["body"]
            

            
            
            _set_if_expression("W1tNQUlOX0ZPVE9dXSA9PSAiIg==");
            _if(VAR_MAIN_FOTO == "",function(){
            
               
               
               _next("function")
               

            })!
            

            
            
            /*Browser*/
            IDDLE_EMULATION_END = Date.now() + 1000 * (1)
            IDDLE_EMULATION_DISTRIBUTION = [2,3,3,3,4,4]
            _get_browser_screen_settings()!
            IDDLE_EMULATION_RESULT = JSON.parse(_result())
            IDDLE_CURSOR_POSITION_X = IDDLE_EMULATION_RESULT["CursorX"]
            IDDLE_CURSOR_POSITION_Y = IDDLE_EMULATION_RESULT["CursorY"]
            IDDLE_CURSOR_POSITION_WIDTH = IDDLE_EMULATION_RESULT["Width"]
            IDDLE_CURSOR_POSITION_HEIGHT = IDDLE_EMULATION_RESULT["Height"]
            IDDLE_CURSOR_POSITION_WAS_SCROLL = false
            _do(function(){
            if(Date.now() >= IDDLE_EMULATION_END)
            _break()
            IDDLE_EMULATION_CURRENT_ITEM = IDDLE_EMULATION_DISTRIBUTION[Math.floor(Math.random()*IDDLE_EMULATION_DISTRIBUTION.length)]
            if(_iterator() == 1 && IDDLE_EMULATION_DISTRIBUTION.indexOf(2)>=0)
            IDDLE_EMULATION_CURRENT_ITEM = 2
            _if(IDDLE_EMULATION_CURRENT_ITEM == 1, function(){
            //scroll
            IDDLE_EMULATION_CURRENT_DIRECTION = (rand(1,2) == 2) ? "<MOUSESCROLLUP>" : "<MOUSESCROLLDOWN>"
            if(!IDDLE_CURSOR_POSITION_WAS_SCROLL)
            IDDLE_EMULATION_CURRENT_DIRECTION = "<MOUSESCROLLDOWN>"
            IDDLE_CURSOR_POSITION_WAS_SCROLL = true
            IDDLE_EMULATION_CURRENT_NUMBER = rand(1,5)
            _do(function(){
            if(_iterator() >= IDDLE_EMULATION_CURRENT_NUMBER)
            _break()
            _type(IDDLE_EMULATION_CURRENT_DIRECTION,1000)!
            sleep(rand(300,1000))!
            })!
            })!
            _if(IDDLE_EMULATION_CURRENT_ITEM == 2, function(){
            //long move
            page().script("document.documentElement.scrollLeft")!
            IDDLE_CURSOR_POSITION_SCROLL_X = parseInt(_result())
            page().script("document.documentElement.scrollTop")!
            IDDLE_CURSOR_POSITION_SCROLL_Y = parseInt(_result())
            IDDLE_CURSOR_POSITION_X = rand(1,IDDLE_CURSOR_POSITION_WIDTH)
            IDDLE_CURSOR_POSITION_Y = rand(1,IDDLE_CURSOR_POSITION_HEIGHT)
            move(IDDLE_CURSOR_POSITION_SCROLL_X + IDDLE_CURSOR_POSITION_X,IDDLE_CURSOR_POSITION_SCROLL_Y + IDDLE_CURSOR_POSITION_Y)!
            })!
            _if(IDDLE_EMULATION_CURRENT_ITEM == 3, function(){
            //short move
            if(IDDLE_CURSOR_POSITION_X < 0 || IDDLE_CURSOR_POSITION_Y < 0)
            _break()
            page().script("document.documentElement.scrollLeft")!
            IDDLE_CURSOR_POSITION_SCROLL_X = parseInt(_result())
            page().script("document.documentElement.scrollTop")!
            IDDLE_CURSOR_POSITION_SCROLL_Y = parseInt(_result())
            IDDLE_EMULATION_CURRENT_NUMBER = rand(1,4)
            _do(function(){
            if(_iterator() >= IDDLE_EMULATION_CURRENT_NUMBER)
            _break()
            IDDLE_CURSOR_POSITION_X += rand(-50,50)
            IDDLE_CURSOR_POSITION_Y += rand(-50,50)
            if(IDDLE_CURSOR_POSITION_X > IDDLE_CURSOR_POSITION_WIDTH)
            IDDLE_CURSOR_POSITION_X = IDDLE_CURSOR_POSITION_WIDTH
            if(IDDLE_CURSOR_POSITION_Y > IDDLE_CURSOR_POSITION_HEIGHT)
            IDDLE_CURSOR_POSITION_Y = IDDLE_CURSOR_POSITION_HEIGHT
            if(IDDLE_CURSOR_POSITION_X < 0)
            IDDLE_CURSOR_POSITION_X = 0
            if(IDDLE_CURSOR_POSITION_Y < 0)
            IDDLE_CURSOR_POSITION_Y = 0
            move(IDDLE_CURSOR_POSITION_SCROLL_X + IDDLE_CURSOR_POSITION_X,IDDLE_CURSOR_POSITION_SCROLL_Y + IDDLE_CURSOR_POSITION_Y)!
            _if(rand(1,10) > 3,function(){
            sleep(rand(10,300))!
            })!
            })!
            })!
            _if(IDDLE_EMULATION_CURRENT_ITEM == 4, function(){
            //sleep
            sleep(rand(500,5000))!
            })!
            })!
            

            
            
            /*Browser*/
            _cache_get_all("https://static.geetest.com/nerualpic/original_icon_pic/*")!
            VAR_CACHE_LIST = JSON.parse(_result())
            

            
            
            VAR_LIST_LENGTH = (VAR_CACHE_LIST).length
            

            
            
            _set_if_expression("W1tMSVNUX0xFTkdUSF1dICE9IDM=");
            _if(VAR_LIST_LENGTH != 3,function(){
            
               
               
               VAR_ERROR_FIND_TASK_IMAGES = parseInt(VAR_ERROR_FIND_TASK_IMAGES) + parseInt(1)
               

               
               
               _break("function")
               

            })!
            

            
            
            VAR_ALL_FOTO = [
            VAR_CACHE_LIST[0]["body"],
            VAR_CACHE_LIST[1]["body"],
            VAR_CACHE_LIST[2]["body"]
            ]
            

            
            
            _break("function")
            

         })!
         

         
         
         /*Browser*/
         cache_data_clear()!
         

         
         
         _set_if_expression("W1tFUlJPUl9GSU5EX1RBU0tfSU1BR0VTXV0gPT0gMQ==");
         _if(VAR_ERROR_FIND_TASK_IMAGES == 1,function(){
         
            
            
            VAR_TRY_SOLVE = parseInt(VAR_TRY_SOLVE) + parseInt(1)
            

            
            
            _next("function")
            

         })!
         

         
         
         /*Browser*/
         _SELECTOR = VAR_FOTO_CAPTCHA;
         wait_element(_SELECTOR)!
         get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
         if(_result().length > 0)
         {
         var split = _result().split("|")
         VAR_X = parseInt(split[0])
         VAR_Y = parseInt(split[1])
         VAR_WIDTH = parseInt(split[2])
         VAR_HEIGHT = parseInt(split[3])
         }
         

         
         
         _switch_http_client_main()
         general_timeout_next(15000)
         http_client_post(VAR_URL_ADRESS_SOLVER + "/in.php", ["key",VAR_APIKEY, "method","geetest_icon","main_photo",VAR_MAIN_FOTO,"task_1",VAR_ALL_FOTO[0],"task_2",VAR_ALL_FOTO[1],"task_3",VAR_ALL_FOTO[2]], {"content-type":("multipart"), "encoding":("UTF-8"), "method":("POST"),headers:("")})!
         

         
         
         _switch_http_client_main()
         VAR_SAVED_CONTENT = http_client_encoded_content("utf-8")
         

         
         
         VAR_STRING_CONTAINS = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(ERROR)"})) == "true")
         

         
         
         _set_if_expression("W1tTVFJJTkdfQ09OVEFJTlNdXQ==");
         _if(typeof(VAR_STRING_CONTAINS) !== "undefined" ? (VAR_STRING_CONTAINS) : undefined,function(){
         
            
            
            /*Browser*/
            ;_SELECTOR=VAR_RELOAD_CAPTCHA;
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(_cycle_params().if_else,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               /*Browser*/
               _SELECTOR = VAR_RELOAD_CAPTCHA;
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {} )!
               get_element_selector(_SELECTOR, false).clarify(X,Y)!
               _call(_clarify, {} )!
               mouse(X,Y)!
               })!
               

            })!
            

            
            
            _if(!_cycle_params().if_else,function(){
            
               
               
               fail_user("Fail solve captcha try: " + VAR_TRY_SOLVE,false)
               

            })!
            delete _cycle_params().if_else;
            

            
            
            VAR_TRY_SOLVE = parseInt(VAR_TRY_SOLVE) + parseInt(1)
            

            
            
            _next("function")
            

         })!
         

         
         
         VAR_ID = VAR_SAVED_CONTENT.split("|")[1]
         

         
         
         _do(function(){
         _set_action_info({ name: "While" });
         VAR_CYCLE_INDEX = _iterator() - 1
         BREAK_CONDITION = true;
         if(!BREAK_CONDITION)_break();
         
            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNjA=");
            _if(VAR_CYCLE_INDEX > 60,function(){
            
               
               
               fail_user("Сервис не распознал капчу за 30 секунд",false)
               

            })!
            

            
            
            /*Browser*/
            IDDLE_EMULATION_END = Date.now() + 1000 * (1)
            IDDLE_EMULATION_DISTRIBUTION = [2,3,3,3,4,4]
            _get_browser_screen_settings()!
            IDDLE_EMULATION_RESULT = JSON.parse(_result())
            IDDLE_CURSOR_POSITION_X = IDDLE_EMULATION_RESULT["CursorX"]
            IDDLE_CURSOR_POSITION_Y = IDDLE_EMULATION_RESULT["CursorY"]
            IDDLE_CURSOR_POSITION_WIDTH = IDDLE_EMULATION_RESULT["Width"]
            IDDLE_CURSOR_POSITION_HEIGHT = IDDLE_EMULATION_RESULT["Height"]
            IDDLE_CURSOR_POSITION_WAS_SCROLL = false
            _do(function(){
            if(Date.now() >= IDDLE_EMULATION_END)
            _break()
            IDDLE_EMULATION_CURRENT_ITEM = IDDLE_EMULATION_DISTRIBUTION[Math.floor(Math.random()*IDDLE_EMULATION_DISTRIBUTION.length)]
            if(_iterator() == 1 && IDDLE_EMULATION_DISTRIBUTION.indexOf(2)>=0)
            IDDLE_EMULATION_CURRENT_ITEM = 2
            _if(IDDLE_EMULATION_CURRENT_ITEM == 1, function(){
            //scroll
            IDDLE_EMULATION_CURRENT_DIRECTION = (rand(1,2) == 2) ? "<MOUSESCROLLUP>" : "<MOUSESCROLLDOWN>"
            if(!IDDLE_CURSOR_POSITION_WAS_SCROLL)
            IDDLE_EMULATION_CURRENT_DIRECTION = "<MOUSESCROLLDOWN>"
            IDDLE_CURSOR_POSITION_WAS_SCROLL = true
            IDDLE_EMULATION_CURRENT_NUMBER = rand(1,5)
            _do(function(){
            if(_iterator() >= IDDLE_EMULATION_CURRENT_NUMBER)
            _break()
            _type(IDDLE_EMULATION_CURRENT_DIRECTION,1000)!
            sleep(rand(300,1000))!
            })!
            })!
            _if(IDDLE_EMULATION_CURRENT_ITEM == 2, function(){
            //long move
            page().script("document.documentElement.scrollLeft")!
            IDDLE_CURSOR_POSITION_SCROLL_X = parseInt(_result())
            page().script("document.documentElement.scrollTop")!
            IDDLE_CURSOR_POSITION_SCROLL_Y = parseInt(_result())
            IDDLE_CURSOR_POSITION_X = rand(1,IDDLE_CURSOR_POSITION_WIDTH)
            IDDLE_CURSOR_POSITION_Y = rand(1,IDDLE_CURSOR_POSITION_HEIGHT)
            move(IDDLE_CURSOR_POSITION_SCROLL_X + IDDLE_CURSOR_POSITION_X,IDDLE_CURSOR_POSITION_SCROLL_Y + IDDLE_CURSOR_POSITION_Y)!
            })!
            _if(IDDLE_EMULATION_CURRENT_ITEM == 3, function(){
            //short move
            if(IDDLE_CURSOR_POSITION_X < 0 || IDDLE_CURSOR_POSITION_Y < 0)
            _break()
            page().script("document.documentElement.scrollLeft")!
            IDDLE_CURSOR_POSITION_SCROLL_X = parseInt(_result())
            page().script("document.documentElement.scrollTop")!
            IDDLE_CURSOR_POSITION_SCROLL_Y = parseInt(_result())
            IDDLE_EMULATION_CURRENT_NUMBER = rand(1,4)
            _do(function(){
            if(_iterator() >= IDDLE_EMULATION_CURRENT_NUMBER)
            _break()
            IDDLE_CURSOR_POSITION_X += rand(-50,50)
            IDDLE_CURSOR_POSITION_Y += rand(-50,50)
            if(IDDLE_CURSOR_POSITION_X > IDDLE_CURSOR_POSITION_WIDTH)
            IDDLE_CURSOR_POSITION_X = IDDLE_CURSOR_POSITION_WIDTH
            if(IDDLE_CURSOR_POSITION_Y > IDDLE_CURSOR_POSITION_HEIGHT)
            IDDLE_CURSOR_POSITION_Y = IDDLE_CURSOR_POSITION_HEIGHT
            if(IDDLE_CURSOR_POSITION_X < 0)
            IDDLE_CURSOR_POSITION_X = 0
            if(IDDLE_CURSOR_POSITION_Y < 0)
            IDDLE_CURSOR_POSITION_Y = 0
            move(IDDLE_CURSOR_POSITION_SCROLL_X + IDDLE_CURSOR_POSITION_X,IDDLE_CURSOR_POSITION_SCROLL_Y + IDDLE_CURSOR_POSITION_Y)!
            _if(rand(1,10) > 3,function(){
            sleep(rand(10,300))!
            })!
            })!
            })!
            _if(IDDLE_EMULATION_CURRENT_ITEM == 4, function(){
            //sleep
            sleep(rand(500,5000))!
            })!
            })!
            

            
            
            _switch_http_client_main()
            http_client_get2(VAR_URL_ADRESS_SOLVER + "/res.php?key=" + VAR_APIKEY + "\u0026id=" + VAR_ID,{method:("GET"),headers:("")})!
            

            
            
            _switch_http_client_main()
            VAR_SAVED_CONTENT = http_client_encoded_content("utf-8")
            

            
            
            _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gIT0gIkNBUENIQV9OT1RfUkVBRFki");
            _if(VAR_SAVED_CONTENT != "CAPCHA_NOT_READY",function(){
            
               
               
               _break("function")
               

            })!
            

         })!
         

         
         
         VAR_STRING_CONTAINS = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(ERROR)"})) == "true")
         

         
         
         _set_if_expression("W1tTVFJJTkdfQ09OVEFJTlNdXQ==");
         _if(typeof(VAR_STRING_CONTAINS) !== "undefined" ? (VAR_STRING_CONTAINS) : undefined,function(){
         
            
            
            /*Browser*/
            ;_SELECTOR=VAR_RELOAD_CAPTCHA;
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(_cycle_params().if_else,function(){
            
               
               
               /*Browser*/
               _SELECTOR = VAR_RELOAD_CAPTCHA;
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {} )!
               get_element_selector(_SELECTOR, false).clarify(X,Y)!
               _call(_clarify, {} )!
               mouse(X,Y)!
               })!
               

            })!
            

            
            
            _if(!_cycle_params().if_else,function(){
            
               
               
               fail_user("Fail solve captcha try: " + VAR_TRY_SOLVE,false)
               

            })!
            delete _cycle_params().if_else;
            

            
            
            VAR_TRY_SOLVE = parseInt(VAR_TRY_SOLVE) + parseInt(1)
            

            
            
            _next("function")
            

         })!
         

         
         
         VAR_DATA = VAR_SAVED_CONTENT.split("|")[1].split(":")[1].replace(/x/g, "").replace(/=/g, "").replace(/y/g, "").replace(/y/g, "")
         VAR_LIST_COORDINATES = [
         [parseInt(VAR_DATA.split(";")[0].split(",")[0]), parseInt(VAR_DATA.split(";")[0].split(",")[1])],
         [parseInt(VAR_DATA.split(";")[1].split(",")[0]), parseInt(VAR_DATA.split(";")[1].split(",")[1])],
         [parseInt(VAR_DATA.split(";")[2].split(",")[0]), parseInt(VAR_DATA.split(";")[2].split(",")[1])]
         ]
         

         
         
         _do_with_params({"foreach_data":(VAR_LIST_COORDINATES)},function(){
         _set_action_info({ name: "Foreach" });
         VAR_CYCLE_INDEX = _iterator() - 1
         if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
         VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
         
            
            
            sleep(200)!
            

            
            
            /*Browser*/
            move(VAR_X + VAR_FOREACH_DATA[0],VAR_Y + VAR_FOREACH_DATA[1],  {} )!
            mouse(VAR_X + VAR_FOREACH_DATA[0],VAR_Y + VAR_FOREACH_DATA[1])!
            

         })!
         

         
         
         /*Browser*/
         _SELECTOR = VAR_CAPTCHA_SUBMIT;
         wait_element_visible(_SELECTOR)!
         _call(_random_point, {})!
         _if(_result().length > 0, function(){
         move( {} )!
         get_element_selector(_SELECTOR, false).clarify(X,Y)!
         _call(_clarify, {} )!
         mouse(X,Y)!
         })!
         

         
         
         VAR_TRY_SOLVE = parseInt(VAR_TRY_SOLVE) + parseInt(1)
         

      })!
      

   }
   

