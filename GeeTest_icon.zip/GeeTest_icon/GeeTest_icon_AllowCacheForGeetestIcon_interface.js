<div class="container-fluid">
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Разрешает сохранение кеша с нужных, для работы модуля, сайтов. Разместите в начале потока</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
