<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"bnggsfit", description:"apikey", default_selector: "string", disable_expression:true, disable_int:true, value_string: "", help: {description: "Ваш api ключ с сервиса https://t.me/Xevil_check_bot"} }) %>
<%= _.template($('#input_constructor').html())({id:"ampupdfq", description:"button_capthca", default_selector: "string", disable_expression:true, disable_int:true, value_string: " >CSS> .geetest_btn_click", help: {description: "Идентификатор кнопки, после нажатия которой появляется капча"} }) %>
<%= _.template($('#input_constructor').html())({id:"pxvhlded", description:"captcha_submit", default_selector: "string", disable_expression:true, disable_int:true, value_string: " >CSS> .geetest_submit", help: {description: "Идентификатор кнопки, подтвердить решение"} }) %>
<%= _.template($('#input_constructor').html())({id:"dslwfpak", description:"foto_captcha", default_selector: "string", disable_expression:true, disable_int:true, value_string: " >CSS> .geetest_bg", help: {description: "Идентификатор кнопки, фото капчи"} }) %>
<%= _.template($('#input_constructor').html())({id:"dzqnjgip", description:"reload_captcha", default_selector: "string", disable_expression:true, disable_int:true, value_string: " >CSS> .geetest_refresh", help: {description: "Идентификатор кнопки, обновление капчи"} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Решает geetest ico капчу, введите все нужные значения, и разместите кубик на странице с капчей.</div>
<div class="tr tooltip-paragraph-last-fold">Если капчу не получится решить за 10 потпыток, модуль вернет ошибку</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
